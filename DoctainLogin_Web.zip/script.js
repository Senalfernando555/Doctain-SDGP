let admin = document.querySelector('.admin');
let patient = document.querySelector('.patient');

admin.onclick = function () {
    admin.classList.toggle('active');
    patient.classList.remove('active');
}

patient.onclick = function () {
    patient.classList.toggle('active');
    admin.classList.remove('active');
}


